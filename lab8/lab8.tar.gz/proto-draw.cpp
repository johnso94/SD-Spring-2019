#include<iostream>
#include<fstream>
#include<sstream>
using namespace std;
#include<math.h>
#include<stdlib.h>

#include"Circle.h"
#include"Rectangle.h"
#include"sd_fun.h"

Shape *one_shape = 0;
Color currentColor(0, 200, 0);

int main()
{
  init();

  if (length_of(yaml) < 30) {
    // initialize
  } else {
    // handle a drag motion to create a Rectangle
    bool button_pressed = false;
    if (!button_pressed) {
      int x0, y0, x, y;
      x = touch_pos_x(yaml);
      y = touch_pos_y(yaml);
      x0 = touch_start_pos_x(yaml);
      y0 = touch_start_pos_y(yaml);

      Point2 start(x0, y0);
      one_shape = new Rectangle(start, x - x0, y - y0);
      one_shape->setColor( currentColor );
    }
    yaml[0] = 0;
    one_shape->draw();
    cerr << "drawing!";
  }
  // show a segment as the user does a drag motion
  append(yaml, R"(
event_handling:
  show_drag_segment: true
)");

  quit();
}
